This IPython notebook week1.ipynb does not require any additional
programs.
