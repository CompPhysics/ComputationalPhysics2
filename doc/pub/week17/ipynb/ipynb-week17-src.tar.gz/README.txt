This IPython notebook week17.ipynb does not require any additional
programs.
