This IPython notebook basicMB.ipynb does not require any additional
programs.
