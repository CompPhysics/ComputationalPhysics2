This IPython notebook week18.ipynb does not require any additional
programs.
