This IPython notebook notebook1.ipynb does not require any additional
programs.
