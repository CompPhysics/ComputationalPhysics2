This IPython notebook statanalysis.ipynb does not require any additional
programs.
