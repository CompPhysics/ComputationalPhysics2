This IPython notebook week8.ipynb does not require any additional
programs.
