This IPython notebook notebook2.ipynb does not require any additional
programs.
