This IPython notebook para.ipynb does not require any additional
programs.
