This IPython notebook week6.ipynb does not require any additional
programs.
