This IPython notebook week4.ipynb does not require any additional
programs.
