This IPython notebook week16.ipynb does not require any additional
programs.
