This IPython notebook cg.ipynb does not require any additional
programs.
