This IPython notebook CG.ipynb does not require any additional
programs.
