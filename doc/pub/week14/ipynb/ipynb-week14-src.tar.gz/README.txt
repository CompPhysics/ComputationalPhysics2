This IPython notebook week14.ipynb does not require any additional
programs.
