This IPython notebook Project2VMC.ipynb does not require any additional
programs.
