This IPython notebook Project2.ipynb does not require any additional
programs.
