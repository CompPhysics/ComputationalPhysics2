This IPython notebook Project2QML.ipynb does not require any additional
programs.
