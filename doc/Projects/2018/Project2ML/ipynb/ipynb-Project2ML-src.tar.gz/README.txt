This IPython notebook Project2ML.ipynb does not require any additional
programs.
