This IPython notebook Project2QC.ipynb does not require any additional
programs.
