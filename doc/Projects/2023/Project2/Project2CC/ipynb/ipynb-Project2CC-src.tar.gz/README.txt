This IPython notebook Project2CC.ipynb does not require any additional
programs.
